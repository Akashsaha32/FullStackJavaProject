import {BrowserRouter, Routes, Route} from 'react-router-dom'
import FooterComponent from "./component/FooterComponent"
import Headercomponent from "./component/Headercomponent"
import ListEmployee from "./component/ListEmployee"
import EmployeeComponent from './component/EmployeeComponent'
import ListDepartmentComponent from './component/ListDepartmentComponent'
import DepartmentComponent from './component/DepartmentComponent'

function App() {

  return (
    <>
      <BrowserRouter>
        <Headercomponent/>
        <br/> <br/>
        <Routes>
              {/* // http://localhost:3000 */}
                <Route path='/' element = { <ListEmployee /> }></Route>

                {/* // http://localhost:3000/employees */}
                <Route path='/employees' element = { <ListEmployee /> }></Route>

                {/* // http://localhost:3000/add-employee */}
                <Route path='/add-employee' element = { <EmployeeComponent/>}></Route>

                {/* // http://localhost:3000/edit-employee/1 */}
                <Route path='/edit-employee/:id' element = { <EmployeeComponent /> }></Route>

                <Route path='/departments' element={<ListDepartmentComponent/>}></Route>

                <Route path='/add-dept' element={<DepartmentComponent/>}></Route>

                <Route path='/edit-dept/:id' element={<DepartmentComponent/>}></Route>
            </Routes>
            <br/> <br/>
        <FooterComponent/>
      </BrowserRouter>
    </>
  )
}

export default App
