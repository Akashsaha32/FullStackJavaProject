import React, { useEffect, useState } from 'react'
import { createDept, getById, updateDept } from '../service/DepartmentService';
import { useNavigate, useParams } from 'react-router-dom';

const DepartmentComponent = () => {

    const[departmentName, setDepartmentName] = useState('');
    const[departmentDescription, setDepartmentDescription] = useState('');

    const[errors, setErrors] = useState({
        departmentName : '',
        departmentDescription : ''
    });

    const navigator = useNavigate();

    const {id} = useParams();

    useEffect(() => {
        if(id){
            getById(id).then((response) => {
                setDepartmentName(response.data.departmentName);
                setDepartmentDescription(response.data.departmentDescription);
            }).catch((e) => {console.log(e)})
        }
    },[id])

    function saveAndUpdate(e){
        e.preventDefault();
        if(formValidate()){
            const dept = {departmentName, departmentDescription};
            if(id){
                updateDept(id, dept).then(navigator('/departments')).catch(e => console.log(e))
            }else{
                createDept(dept).then(navigator('/departments')).catch((e) => {console.log(e)});
            }
        }
    }

    function formValidate(){
        let valid = true;
        const errorCopy = {... errors};

        if(departmentName.trim()){
            errorCopy.departmentName = '';
        }else{
            errorCopy.departmentName = "Department Name Required";
            valid = false;
        }

        if(departmentDescription.trim()){
            errorCopy.departmentDescription = '';
        }else{
            errorCopy.departmentDescription = "Description Required"
            valid = false;
        }
        setErrors(errorCopy);
        return valid;
    }

    function back(){
        navigator('/departments')
    }

    function pageTitle(){
        if(id){
            return <h3 style={{textAlign:'center'}}>Update Department</h3>
        }else{
            return <h3 style={{textAlign:'center'}}>ADD Department</h3>
        }
    }

  return (
    <div className='container'><br/>
        <div className='row'>
            <div className='card col-md-6 offset-md-3 offset-md-3'><br/>
                {
                    pageTitle()
                }
                <div className='card-body'>
                    <form>
                        <div className='form-group mb-2'>
                            <label className='form-label'>Department Name</label>
                            <input
                                placeholder='Enter Department Name'
                                className={`form-control ${errors.departmentName ? 'is-invalid' : ''}`}
                                //name='departmentName'
                                value={departmentName}
                                onChange={(e) => setDepartmentName(e.target.value)}
                            ></input>
                            {errors.departmentName && <div className='invalid-feedback'>{errors.departmentName}</div>}
                        </div>

                        <div className='form-group mb-2'>
                            <label className='form-label'>Department Description</label>
                            <input
                                placeholder='Department Description'
                                className={`form-control ${errors.departmentDescription ? 'is-invalid' : ''}`}
                                //name='departmentDescription'
                                value={departmentDescription}
                                onChange={(e) => setDepartmentDescription(e.target.value)}
                            ></input>
                            {errors.departmentDescription && <div className='invalid-feedback'>{errors.departmentDescription}</div>}
                        </div>
                        <button className='btn btn-success' onClick={saveAndUpdate}>Submit</button>
                        <button className='btn btn-info' style={{marginLeft:'10px'}} onClick={back}>Back</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
  )
}

export default DepartmentComponent