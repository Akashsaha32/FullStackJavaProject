import React from 'react'

const Headercomponent = () => {
  return (
    <div>
        <header className='header'>
            <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
                <div className='collapse navbar-collapse'>
                  <ul className='navbar-nav mr-auto'>
                    <li className="nav-item active">
                      <a className="nav-link" href="/">Employee Management System</a>
                    </li>
                    <li className="nav-item active">
                      <a className="nav-link" href="/employees">Employees</a>
                    </li>
                    <li className="nav-item">
                      <a className="nav-link" href="/departments">Departments</a>
                    </li>
                  </ul>
                </div>
            </nav>
        </header>
    </div>
  )
}

export default Headercomponent