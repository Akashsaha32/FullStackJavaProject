import React, { useEffect, useState } from 'react'
import { deleteDept, departmentList } from '../service/DepartmentService';
import { useNavigate } from 'react-router-dom';

const ListDepartmentComponent = () => {

    const[department, setDepartment] = useState([]);

    function getAllDept(){
        departmentList().then((response) => {
            setDepartment(response.data);
        }).catch((e) => {
            console.log(e);
        })
    }

    useEffect(() => {
        getAllDept();
    })

    const navigator = useNavigate();

    function createDept(){
        navigator('/add-dept');
    }

    function removeDept(id){
        deleteDept(id).then(getAllDept()).catch((e) => {console.log(e)})
    }

    function editDept(id){
        navigator(`/edit-dept/${id}`);
    }

  return (
    <div className='container'><br/>
        <h2 className='text-center'>Department List</h2><br/>
        <button className='btn btn-info' style={{marginBottom:'10px'}} onClick={createDept}>Add Department</button>
        <table className='table table-striped table-bordered text-center'>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Department Name</th>
                    <th>Department Description</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                {
                    department.map(dep => 
                        <tr key={dep.id}>
                            <td>{dep.id}</td>
                            <td>{dep.departmentName}</td>
                            <td>{dep.departmentDescription}</td>
                            <td>
                                <button className='btn btn-success' style={{marginRight:'10px'}} onClick={() => editDept(dep.id)}>Update</button>
                                <button className='btn btn-danger' onClick={() => removeDept(dep.id)}>Delete</button>
                            </td>
                        </tr>
                    )
                }
            </tbody>
        </table>
    </div>
  )
}

export default ListDepartmentComponent