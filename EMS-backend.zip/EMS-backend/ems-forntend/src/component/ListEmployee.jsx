import React, { useEffect, useState } from 'react'
import { deleteEmployee, listEmployeeUrl } from '../service/EmployeeService';
import { useNavigate } from 'react-router-dom';

const ListEmployee = () => {
    const [employees, setEmployees] = useState([]);

    const navigator = useNavigate();

    useEffect(() => {
        getAllEmployee();
    })

    function getAllEmployee(){
        listEmployeeUrl().then(response => {
            setEmployees(response.data)
        }).catch(error =>{
            console.error(error);
        })
    }
    
    function updateEmployee(id){
        navigator(`/edit-employee/${id}`);
    }

    function removeEmployee(id){
        console.log(id);
        deleteEmployee(id).then(
            getAllEmployee()
        ).catch(error => {
            console.error(error);
        })
    }

    function addNewEmployee(){
        navigator('/add-employee');
    }

  return (
    <div className='container'>
        <h2 className='h1-text text-center'>List Of Employee...</h2>
        <button className='btn btn-primary' style={{margin: '10px'}} onClick={addNewEmployee}>Add Employee</button>
        <table className='table table-striped table-bordered text-center'>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>E_mail</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                {
                    employees.map(employee =>
                        <tr key={employee.id}>
                            <td>{employee.id}</td>
                            <td>{employee.firstName}</td>
                            <td>{employee.lastName}</td>
                            <td>{employee.email}</td>
                            <td >
                                <button type='button' className='btn btn-info' onClick={() => updateEmployee(employee.id)}>Update</button>
                                <button type='button' style={{marginLeft:'10px'}} className='btn btn-danger' onClick={() => removeEmployee(employee.id)}>Delete</button>
                            </td>
                        </tr>)
                }
            </tbody>
        </table>
    </div>
  )
}

export default ListEmployee